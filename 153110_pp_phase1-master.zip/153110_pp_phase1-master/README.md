# 153110_pp_phase1
Parrallel project Phase 1 using Collections is completed
